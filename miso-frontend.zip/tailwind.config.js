/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        grid: {
          bg: "#0B1220",
          panel: "#121B2C",
          panel2: "#182338",
          line: "#28344A",
          muted: "#8B96AC",
          text: "#E8ECF3",
        },
        teal: {
          DEFAULT: "#3FD6C6",
          dim: "#1F5A54",
        },
        amber: {
          DEFAULT: "#E8A33D",
          dim: "#5C4520",
        },
      },
      fontFamily: {
        mono: ["IBM Plex Mono", "ui-monospace", "SFMono-Regular", "monospace"],
        sans: ["IBM Plex Sans", "ui-sans-serif", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
