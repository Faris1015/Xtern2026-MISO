/**
 * Types mirror the Pydantic models in backend/search_engine.py and
 * backend/main.py exactly (field names, casing, optionality) so the
 * frontend never guesses at the wire shape.
 */

export type AudienceMode =
  | "Power Trader"
  | "Municipal Co-op"
  | "Public / Media"
  | "State Regulator";

export type ChartType = "lmp_series" | "fuel_mix" | "transmission_bar" | "glossary_card";

export type CompareType = "hubs" | "fuels" | "plans";

export interface KpiCard {
  label: string;
  value: string;
  /** sky | slate | red | emerald | amber | purple */
  color: string;
}

export interface FollowUpAction {
  label: string;
  action: string;
  params: Record<string, unknown>;
}

/** One row of `hub.hourly`, from backend/data_manager.py's generate_default_market_hubs(). */
export interface HourlyLmpRow {
  hourEnding: number;
  intervalLabel: string;
  realTimeLmp: number;
  dayAheadLmp: number;
  spread: number;
  energyComponent?: number;
  congestionComponent?: number;
  lossComponent?: number;
  volumeMwh: number;
}

export interface HubSummary {
  realTimeAvg: number;
  dayAheadAvg: number;
  peakHour: string;
  peakPrice?: number;
  peakHE?: number;
  totalVolumeMwh?: number;
  formattedVolume: string;
}

export interface Hub {
  hubId: string;
  hubName: string;
  region?: string;
  summary: HubSummary;
  hourly: HourlyLmpRow[];
}

export interface FuelMixItem {
  fuel: string;
  percentage: number;
  /** Hex color from data_manager.py — use this directly for chart fills instead of a hardcoded palette. */
  color?: string;
  installedGw?: number;
}

export interface TransmissionCategory {
  id: string;
  categoryName: string;
  projectsCount: number;
  miles: number;
  investmentEst: string;
  focus: string;
}

export interface GlossaryEntry {
  acronym: string;
  term: string;
  eli5: string;
  technical: string;
  formula?: string;
  category?: string;
}

/** GET /api/search */
export interface SearchResponse {
  query: string;
  directAnswer: string;
  sourceCitation: string;
  kpis: KpiCard[];
  chartType: ChartType;
  hubId?: string | null;
  /** Shape depends on chartType: HourlyLmpRow[] | FuelMixItem[] | TransmissionCategory[] | GlossaryEntry */
  data?: HourlyLmpRow[] | FuelMixItem[] | TransmissionCategory[] | GlossaryEntry | null;
  proactiveFollowUps: FollowUpAction[];
}

export interface QuickStartChip {
  label: string;
  query: string;
  type: string;
}

export interface RecordPeak {
  valueGw: number;
  date: string;
  time?: string;
  description?: string;
}

export interface RecentPeaks {
  solarPeak: RecordPeak;
  windPeak: RecordPeak;
  allTimeDemandRecord: RecordPeak;
}

/** GET /api/session-prefetch */
export interface SessionPrefetchResponse {
  sessionContext: string;
  timestamp: string;
  featuredHub: Hub;
  generationMixSummary: FuelMixItem[];
  recentPeaks: RecentPeaks;
  quickStartChips: QuickStartChip[];
}

/** GET /api/compare */
export interface ComparisonResponse {
  compareType: CompareType;
  items: string[];
  title: string;
  metricsSummary: Record<string, unknown>[];
  series: Record<string, unknown>[];
  sourceCitation: string;
}

export interface ApiErrorShape {
  detail: string;
}

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
    this.name = "ApiError";
  }
}
