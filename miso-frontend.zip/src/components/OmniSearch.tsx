import { useEffect, useMemo, useRef, useState } from "react";
import { Search, X, Command } from "lucide-react";
import type { AudienceMode } from "../types";

interface Suggestion {
  label: string;
  category: "Market Pricing" | "Generation & Peaks" | "Transmission Planning" | "Jargon Acronyms";
}

/**
 * Static suggestion set per Issue #3. The backend has no dedicated
 * /api/suggest endpoint — search intent is resolved entirely by
 * /api/search — so autosuggest is a fast, local shortlist of the
 * query strings search_engine.py is built to recognize.
 */
const SUGGESTIONS: Suggestion[] = [
  { label: "Indiana Hub LMPs", category: "Market Pricing" },
  { label: "Michigan Hub Spreads", category: "Market Pricing" },
  { label: "Illinois Hub LMP", category: "Market Pricing" },
  { label: "Texas Hub Day-Ahead Price", category: "Market Pricing" },
  { label: "Solar Peak Record", category: "Generation & Peaks" },
  { label: "Wind Peak Record", category: "Generation & Peaks" },
  { label: "Current Fuel Mix", category: "Generation & Peaks" },
  { label: "All-Time Demand Peak", category: "Generation & Peaks" },
  { label: "MTEP24 LRTP Tranche 2", category: "Transmission Planning" },
  { label: "JTIQ Seam Upgrades", category: "Transmission Planning" },
  { label: "Local MTEP Reliability Projects", category: "Transmission Planning" },
  { label: "What is CONE?", category: "Jargon Acronyms" },
  { label: "Explain LMP formula", category: "Jargon Acronyms" },
  { label: "What is LRTP?", category: "Jargon Acronyms" },
];

const AUDIENCE_MODES: AudienceMode[] = [
  "Power Trader",
  "Municipal Co-op",
  "Public / Media",
  "State Regulator",
];

const CATEGORY_ORDER: Suggestion["category"][] = [
  "Market Pricing",
  "Generation & Peaks",
  "Transmission Planning",
  "Jargon Acronyms",
];

const CATEGORY_BADGE: Record<Suggestion["category"], string> = {
  "Market Pricing": "🏷️ Market Pricing",
  "Generation & Peaks": "🏷️ Generation & Peaks",
  "Transmission Planning": "🏷️ Transmission Planning",
  "Jargon Acronyms": "🏷️ Jargon Acronyms",
};

interface OmniSearchProps {
  persona: AudienceMode;
  onPersonaChange: (persona: AudienceMode) => void;
  onSearch: (query: string) => void;
  isLoading?: boolean;
}

export default function OmniSearch({
  persona,
  onPersonaChange,
  onSearch,
  isLoading = false,
}: OmniSearchProps) {
  const [value, setValue] = useState("");
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const filtered = useMemo(() => {
    const q = value.trim().toLowerCase();
    const pool = q.length === 0 ? SUGGESTIONS : SUGGESTIONS.filter((s) => s.label.toLowerCase().includes(q));
    return CATEGORY_ORDER.flatMap((cat) => pool.filter((s) => s.category === cat));
  }, [value]);

  // "/" or Ctrl+K / Cmd+K focuses the search bar from anywhere on the page.
  useEffect(() => {
    function handleGlobalKeydown(e: KeyboardEvent) {
      const target = e.target as HTMLElement | null;
      const isTypingElsewhere =
        target &&
        target !== inputRef.current &&
        (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable);

      if (isTypingElsewhere) return;

      if ((e.key === "/" && target !== inputRef.current) || ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k")) {
        e.preventDefault();
        inputRef.current?.focus();
        setOpen(true);
      }
    }
    window.addEventListener("keydown", handleGlobalKeydown);
    return () => window.removeEventListener("keydown", handleGlobalKeydown);
  }, []);

  // Close the suggestion list on outside click.
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  function submit(query: string) {
    const trimmed = query.trim();
    if (!trimmed) return;
    onSearch(trimmed);
    setValue(trimmed);
    setOpen(false);
    setActiveIndex(-1);
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (!open && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
      setOpen(true);
      return;
    }
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIndex((i) => (i + 1) % Math.max(filtered.length, 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((i) => (i <= 0 ? filtered.length - 1 : i - 1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (activeIndex >= 0 && filtered[activeIndex]) {
        submit(filtered[activeIndex].label);
      } else {
        submit(value);
      }
    } else if (e.key === "Escape") {
      setOpen(false);
      setActiveIndex(-1);
    }
  }

  return (
    <div className="w-full">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="font-sans text-lg font-semibold tracking-tight text-grid-text">
          MISO OmniSearch
        </h1>

        {/* Audience Mode Toggle — 4-way selector */}
        <div
          role="radiogroup"
          aria-label="Audience mode"
          className="flex flex-wrap gap-1 rounded-md border border-grid-line bg-grid-panel p-1"
        >
          {AUDIENCE_MODES.map((mode) => (
            <button
              key={mode}
              role="radio"
              aria-checked={persona === mode}
              onClick={() => onPersonaChange(mode)}
              className={`rounded px-2.5 py-1.5 text-xs font-medium transition-colors sm:text-sm ${
                persona === mode
                  ? "bg-teal/15 text-teal"
                  : "text-grid-muted hover:text-grid-text"
              }`}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>

      <div ref={containerRef} className="relative mt-3">
        <div className="flex items-center gap-2 rounded-lg border border-grid-line bg-grid-panel px-3 py-2.5 focus-within:border-teal/60">
          <Search size={18} className="shrink-0 text-grid-muted" aria-hidden="true" />
          <input
            ref={inputRef}
            role="combobox"
            aria-expanded={open}
            aria-controls="omnisearch-listbox"
            aria-autocomplete="list"
            value={value}
            placeholder="Search hubs, fuel mix, transmission plans, or ask what an acronym means…"
            onChange={(e) => {
              setValue(e.target.value);
              setOpen(true);
              setActiveIndex(-1);
            }}
            onFocus={() => setOpen(true)}
            onKeyDown={handleKeyDown}
            className="w-full bg-transparent text-sm text-grid-text placeholder:text-grid-muted focus:outline-none sm:text-base"
          />
          {value && (
            <button
              type="button"
              aria-label="Clear search"
              onClick={() => {
                setValue("");
                setActiveIndex(-1);
                inputRef.current?.focus();
              }}
              className="shrink-0 text-grid-muted hover:text-grid-text"
            >
              <X size={16} />
            </button>
          )}
          <kbd className="hidden shrink-0 items-center gap-1 rounded border border-grid-line px-1.5 py-0.5 text-[11px] text-grid-muted sm:flex">
            <Command size={11} /> K
          </kbd>
        </div>

        {open && filtered.length > 0 && (
          <ul
            id="omnisearch-listbox"
            role="listbox"
            className="absolute z-20 mt-1.5 max-h-80 w-full overflow-y-auto rounded-lg border border-grid-line bg-grid-panel2 shadow-lg shadow-black/30"
          >
            {CATEGORY_ORDER.map((cat) => {
              const items = filtered.filter((s) => s.category === cat);
              if (items.length === 0) return null;
              return (
                <li key={cat} role="none">
                  <div className="px-3 pt-2 text-[11px] font-medium text-grid-muted">
                    {CATEGORY_BADGE[cat]}
                  </div>
                  {items.map((s) => {
                    const globalIndex = filtered.indexOf(s);
                    const isActive = globalIndex === activeIndex;
                    return (
                      <button
                        key={s.label}
                        role="option"
                        aria-selected={isActive}
                        onMouseEnter={() => setActiveIndex(globalIndex)}
                        onClick={() => submit(s.label)}
                        className={`block w-full px-3 py-2 text-left text-sm ${
                          isActive ? "bg-teal/10 text-teal" : "text-grid-text hover:bg-white/5"
                        }`}
                      >
                        {s.label}
                      </button>
                    );
                  })}
                </li>
              );
            })}
          </ul>
        )}
      </div>

      {isLoading && (
        <p className="mt-2 text-xs text-grid-muted" role="status">
          Searching MISO datasets…
        </p>
      )}
    </div>
  );
}
