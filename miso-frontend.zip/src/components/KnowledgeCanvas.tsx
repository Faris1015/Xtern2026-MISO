import { useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { FileText, Download, FileDown, Loader2 } from "lucide-react";
import { downloadCsv, downloadBlob, generateBriefing } from "../lib/api";
import type {
  AudienceMode,
  FollowUpAction,
  FuelMixItem,
  GlossaryEntry,
  HourlyLmpRow,
  SearchResponse,
  TransmissionCategory,
} from "../types";

const KPI_COLOR_CLASSES: Record<string, string> = {
  sky: "border-sky-400/30 bg-sky-400/10 text-sky-300",
  slate: "border-slate-400/30 bg-slate-400/10 text-slate-300",
  red: "border-red-400/30 bg-red-400/10 text-red-300",
  emerald: "border-emerald-400/30 bg-emerald-400/10 text-emerald-300",
  amber: "border-amber-400/30 bg-amber-400/10 text-amber-300",
  purple: "border-purple-400/30 bg-purple-400/10 text-purple-300",
};

const DONUT_COLORS = ["#3FD6C6", "#E8A33D", "#8B96AC", "#C084FC", "#F87171", "#4ADE80"];

interface KnowledgeCanvasProps {
  result: SearchResponse | null;
  loading: boolean;
  error: string | null;
  persona: AudienceMode;
  onSearch: (query: string) => void;
  onCompareHubs: (hubs: string[]) => void;
  onCompareFuels: (fuels: string[]) => void;
  onComparePlans: () => void;
}

export default function KnowledgeCanvas({
  result,
  loading,
  error,
  persona,
  onSearch,
  onCompareHubs,
  onCompareFuels,
  onComparePlans,
}: KnowledgeCanvasProps) {
  const [citationOpen, setCitationOpen] = useState(false);
  const [isDownloadingPdf, setIsDownloadingPdf] = useState(false);
  const [downloadError, setDownloadError] = useState<string | null>(null);

  const tabularData = useMemo(() => {
    if (!result?.data || !Array.isArray(result.data)) return null;
    return result.data as unknown as Record<string, unknown>[];
  }, [result]);

  if (loading) {
    return (
      <div
        className="mt-4 flex items-center justify-center gap-2 rounded-lg border border-grid-line bg-grid-panel py-16 text-grid-muted"
        role="status"
      >
        <Loader2 size={18} className="animate-spin" />
        Building the 360° Knowledge Canvas…
      </div>
    );
  }

  if (error) {
    return (
      <div className="mt-4 rounded-lg border border-red-400/30 bg-red-400/5 px-4 py-4 text-sm text-red-300">
        Couldn't load that search. {error}
      </div>
    );
  }

  if (!result) {
    return (
      <div className="mt-4 rounded-lg border border-dashed border-grid-line px-4 py-10 text-center text-sm text-grid-muted">
        Search a hub, fuel type, transmission plan, or acronym above to build a canvas.
      </div>
    );
  }

  /**
   * Handles every `action` string actually present in
   * backend/data/related_queries.json. Actions with a real backend
   * or client-side capability behind them (search, compare, PDF,
   * CSV) get a concrete handler; the rest (view_queue,
   * view_curtailment, download_guide, view_zones, etc.) have no
   * dedicated route on the backend today, so they fall back to
   * re-running the pill's own label as a fresh OmniSearch query —
   * that's a real, working search rather than a dead button.
   */
  function handleFollowUp(f: FollowUpAction) {
    const params = f.params ?? {};
    switch (f.action) {
      case "search":
        if (typeof params.q === "string") onSearch(params.q);
        break;
      case "compare_hubs":
        if (Array.isArray(params.hubs)) onCompareHubs(params.hubs as string[]);
        break;
      case "compare_fuels":
        onCompareFuels(Array.isArray(params.fuels) ? (params.fuels as string[]) : []);
        break;
      case "compare_plans":
        onComparePlans();
        break;
      case "generate_briefing":
        void triggerPdfDownload(typeof params.hub === "string" ? params.hub : undefined);
        break;
      case "show_spread": {
        const hub = typeof params.hub === "string" ? params.hub.replace(".HUB", "") : "Indiana";
        onSearch(`${hub} Hub LMP spread`);
        break;
      }
      case "download_csv":
        if (tabularData) {
          const hub = typeof params.hub === "string" ? params.hub.replace(".HUB", "") : "miso";
          downloadCsv(tabularData, `${hub}_hourly.csv`);
        }
        break;
      case "view_tariff":
      case "view_glossary":
        onSearch(typeof params.term === "string" ? params.term : f.label);
        break;
      default:
        onSearch(f.label);
    }
  }

  async function triggerPdfDownload(hubOverride?: string) {
    setDownloadError(null);
    setIsDownloadingPdf(true);
    try {
      const hubId = hubOverride ?? result!.hubId ?? "INDIANA.HUB";
      const blob = await generateBriefing(hubId, persona);
      downloadBlob(blob, `MISO_Briefing_${hubId.replace(".HUB", "")}.pdf`);
    } catch (err) {
      setDownloadError(err instanceof Error ? err.message : "PDF generation failed.");
    } finally {
      setIsDownloadingPdf(false);
    }
  }

  function handleDownloadPdf() {
    void triggerPdfDownload();
  }

  function handleDownloadCsv() {
    if (!tabularData) return;
    downloadCsv(tabularData, `${(result!.hubId ?? result!.chartType).replace(".HUB", "")}_data.csv`);
  }

  return (
    <div className="mt-4 rounded-lg border border-grid-line bg-grid-panel p-4 sm:p-5">
      {/* Direct Answer Block */}
      <div className="border-b border-grid-line pb-4">
        <p className="whitespace-pre-line text-sm leading-relaxed text-grid-text sm:text-base">
          {result.directAnswer}
        </p>
        <div className="relative mt-2 inline-block">
          <button
            onClick={() => setCitationOpen((v) => !v)}
            aria-expanded={citationOpen}
            className="inline-flex items-center gap-1 rounded border border-grid-line px-2 py-1 text-xs text-grid-muted hover:text-teal"
          >
            <FileText size={12} /> Source
          </button>
          {citationOpen && (
            <div className="absolute left-0 z-10 mt-1 w-72 rounded-md border border-grid-line bg-grid-panel2 p-2.5 text-xs text-grid-muted shadow-lg">
              {result.sourceCitation}
            </div>
          )}
        </div>
      </div>

      {/* KPI Stats Row */}
      <div className="grid grid-cols-2 gap-3 py-4 sm:grid-cols-4">
        {result.kpis.map((kpi) => (
          <div
            key={kpi.label}
            className={`rounded-md border px-3 py-2.5 ${KPI_COLOR_CLASSES[kpi.color] ?? KPI_COLOR_CLASSES.slate}`}
          >
            <div className="text-[11px] font-medium uppercase tracking-wide opacity-80">
              {kpi.label}
            </div>
            <div className="num mt-1 text-lg font-semibold sm:text-xl">{kpi.value}</div>
          </div>
        ))}
      </div>

      {/* Interactive Recharts Visualizer */}
      <div className="border-t border-grid-line pt-4">
        <ChartByType chartType={result.chartType} data={result.data} />
      </div>

      {/* Proactive Follow-Up Radar */}
      {result.proactiveFollowUps.length > 0 && (
        <div className="mt-4 flex flex-wrap gap-2 border-t border-grid-line pt-4">
          {result.proactiveFollowUps.map((f) => (
            <button
              key={f.label}
              onClick={() => handleFollowUp(f)}
              className="rounded-full border border-grid-line px-3 py-1.5 text-xs font-medium text-grid-text transition-colors hover:border-teal/60 hover:text-teal"
            >
              {f.label}
            </button>
          ))}
        </div>
      )}

      {/* 1-Click Export Actions */}
      <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-grid-line pt-4">
        <button
          onClick={handleDownloadPdf}
          disabled={isDownloadingPdf}
          className="inline-flex items-center gap-1.5 rounded-md bg-teal/15 px-3 py-1.5 text-xs font-medium text-teal transition-colors hover:bg-teal/25 disabled:opacity-50"
        >
          {isDownloadingPdf ? <Loader2 size={14} className="animate-spin" /> : <FileDown size={14} />}
          Download 1-Page PDF Fact Sheet
        </button>
        <button
          onClick={handleDownloadCsv}
          disabled={!tabularData}
          className="inline-flex items-center gap-1.5 rounded-md border border-grid-line px-3 py-1.5 text-xs font-medium text-grid-text transition-colors hover:border-teal/60 hover:text-teal disabled:opacity-40"
        >
          <Download size={14} />
          Download Filtered CSV
        </button>
        {downloadError && <span className="text-xs text-red-300">{downloadError}</span>}
      </div>
    </div>
  );
}

function ChartByType({
  chartType,
  data,
}: {
  chartType: SearchResponse["chartType"];
  data: SearchResponse["data"];
}) {
  if (chartType === "lmp_series" && Array.isArray(data)) {
    const rows = data as HourlyLmpRow[];
    const chartData = rows.map((r, i) => ({
      label: r.intervalLabel ?? `HE ${i + 1}`,
      "Real-Time LMP": r.realTimeLmp,
      "Day-Ahead LMP": r.dayAheadLmp,
    }));
    return (
      <ResponsiveContainer width="100%" height={280}>
        <AreaChart data={chartData} margin={{ top: 4, right: 8, left: -12, bottom: 0 }}>
          <defs>
            <linearGradient id="rtFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#3FD6C6" stopOpacity={0.35} />
              <stop offset="95%" stopColor="#3FD6C6" stopOpacity={0.02} />
            </linearGradient>
            <linearGradient id="daFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#E8A33D" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#E8A33D" stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#28344A" vertical={false} />
          <XAxis dataKey="label" stroke="#8B96AC" tick={{ fontSize: 11 }} />
          <YAxis stroke="#8B96AC" tick={{ fontSize: 11 }} unit="$" />
          <Tooltip
            contentStyle={{ background: "#182338", border: "1px solid #28344A", fontSize: 12 }}
            labelStyle={{ color: "#E8ECF3" }}
          />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          <Area type="monotone" dataKey="Real-Time LMP" stroke="#3FD6C6" fill="url(#rtFill)" strokeWidth={2} />
          <Area type="monotone" dataKey="Day-Ahead LMP" stroke="#E8A33D" fill="url(#daFill)" strokeWidth={2} />
        </AreaChart>
      </ResponsiveContainer>
    );
  }

  if (chartType === "fuel_mix" && Array.isArray(data)) {
    const rows = data as FuelMixItem[];
    return (
      <ResponsiveContainer width="100%" height={280}>
        <PieChart>
          <Pie
            data={rows}
            dataKey="percentage"
            nameKey="fuel"
            innerRadius={60}
            outerRadius={100}
            paddingAngle={2}
          >
            {rows.map((entry, i) => (
              <Cell key={entry.fuel} fill={entry.color ?? DONUT_COLORS[i % DONUT_COLORS.length]} />
            ))}
          </Pie>
          <Tooltip
            contentStyle={{ background: "#182338", border: "1px solid #28344A", fontSize: 12 }}
            formatter={(value: number) => `${value}%`}
          />
          <Legend wrapperStyle={{ fontSize: 12 }} />
        </PieChart>
      </ResponsiveContainer>
    );
  }

  if (chartType === "transmission_bar" && Array.isArray(data)) {
    const rows = data as TransmissionCategory[];
    return (
      <ResponsiveContainer width="100%" height={280}>
        <BarChart data={rows} margin={{ top: 4, right: 8, left: -12, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#28344A" vertical={false} />
          <XAxis dataKey="categoryName" stroke="#8B96AC" tick={{ fontSize: 11 }} />
          <YAxis stroke="#8B96AC" tick={{ fontSize: 11 }} />
          <Tooltip contentStyle={{ background: "#182338", border: "1px solid #28344A", fontSize: 12 }} />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          <Bar dataKey="projectsCount" name="Projects" fill="#3FD6C6" radius={[4, 4, 0, 0]} />
          <Bar dataKey="miles" name="Line Miles" fill="#E8A33D" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    );
  }

  if (chartType === "glossary_card" && data && !Array.isArray(data)) {
    const entry = data as GlossaryEntry;
    return (
      <div className="rounded-md border border-grid-line bg-grid-panel2 p-4 text-sm text-grid-text">
        <div className="text-xs uppercase tracking-wide text-grid-muted">{entry.category ?? "Market Rule"}</div>
        <div className="mt-1 font-mono text-teal">{entry.acronym}</div>
        <div className="mt-1 text-grid-muted">{entry.term}</div>
        {entry.formula && (
          <pre className="mt-3 overflow-x-auto rounded bg-grid-bg px-3 py-2 text-xs text-amber">
            {entry.formula}
          </pre>
        )}
      </div>
    );
  }

  return (
    <div className="flex h-40 items-center justify-center rounded-md border border-dashed border-grid-line text-xs text-grid-muted">
      No chartable series for this result.
    </div>
  );
}
