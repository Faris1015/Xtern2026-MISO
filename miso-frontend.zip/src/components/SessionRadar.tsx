import { useEffect, useState } from "react";
import { Radar, ArrowRight } from "lucide-react";
import { getSessionPrefetch } from "../lib/api";
import type { SessionPrefetchResponse } from "../types";

interface SessionRadarProps {
  /** Called with the chip's query string, or "__compare__" for compare-type chips. */
  onChipSelect: (query: string, type: string) => void;
}

export default function SessionRadar({ onChipSelect }: SessionRadarProps) {
  const [data, setData] = useState<SessionPrefetchResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    getSessionPrefetch(controller.signal)
      .then(setData)
      .catch((err: unknown) => {
        if (controller.signal.aborted) return;
        setError(err instanceof Error ? err.message : "Session pre-fetch unavailable.");
      });
    return () => controller.abort();
  }, []);

  if (error) {
    // Fail quietly — the omnisearch bar above still works without a
    // pre-fetched session, this banner is a convenience layer only.
    return null;
  }

  if (!data) {
    return (
      <div
        className="mt-3 flex items-center gap-2 rounded-lg border border-grid-line bg-grid-panel px-4 py-2.5 text-sm text-grid-muted"
        role="status"
      >
        <Radar size={16} className="radar-pulse text-teal" />
        Reading active session…
      </div>
    );
  }

  return (
    <div className="mt-3 rounded-lg border border-teal/30 bg-teal/5 px-4 py-3">
      <div className="flex items-start gap-2">
        <Radar size={16} className="radar-pulse mt-0.5 shrink-0 text-teal" aria-hidden="true" />
        <p className="text-sm text-grid-text">
          <span className="font-medium text-teal">Active Session Radar:</span>{" "}
          {data.sessionContext.replace(/^Active Session Radar:\s*/i, "")}
          {" "}Click to pre-load briefing.
        </p>
      </div>
      <div className="mt-2.5 flex flex-wrap gap-2">
        {data.quickStartChips.map((chip) => (
          <button
            key={chip.label}
            onClick={() => onChipSelect(chip.query, chip.type)}
            className="group inline-flex items-center gap-1 rounded-full border border-grid-line bg-grid-panel px-3 py-1 text-xs font-medium text-grid-text transition-colors hover:border-teal/60 hover:text-teal"
          >
            {chip.label}
            <ArrowRight size={12} className="opacity-0 transition-opacity group-hover:opacity-100" />
          </button>
        ))}
      </div>
    </div>
  );
}
