import { useEffect, useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Loader2, Zap } from "lucide-react";
import { compare } from "../lib/api";
import type { CompareType, ComparisonResponse } from "../types";

const HUB_OPTIONS: { id: string; label: string }[] = [
  { id: "INDIANA.HUB", label: "Indiana" },
  { id: "MICHIGAN.HUB", label: "Michigan" },
  { id: "ILLINOIS.HUB", label: "Illinois" },
  { id: "TEXAS.HUB", label: "Texas" },
  { id: "MINN.HUB", label: "Minnesota" },
  { id: "LOUISIANA.HUB", label: "Louisiana" },
];

const FUEL_OPTIONS = ["Wind", "Solar", "Natural Gas", "Coal", "Nuclear"];

const LINE_COLORS = ["#3FD6C6", "#E8A33D", "#C084FC", "#F87171", "#4ADE80", "#60A5FA"];

const COMPARE_TABS: { id: CompareType; label: string }[] = [
  { id: "hubs", label: "Hubs" },
  { id: "fuels", label: "Fuel Types" },
  { id: "plans", label: "Transmission Plans" },
];

interface ComparisonMatrixProps {
  /** Pre-selects hubs when a "compare_hubs" follow-up (e.g. "Compare Indiana vs. Michigan") triggers this panel. */
  initialHubs?: string[];
  /** Pre-selects fuels when a "compare_fuels" follow-up triggers this panel. */
  initialFuels?: string[];
  /** Bumped by the parent every time it wants this panel to switch tabs — see App.tsx. */
  focusToken?: number;
  initialCompareType?: CompareType;
}

export default function ComparisonMatrix({
  initialHubs,
  initialFuels,
  focusToken,
  initialCompareType,
}: ComparisonMatrixProps) {
  const [compareType, setCompareType] = useState<CompareType>(initialCompareType ?? "hubs");
  const [selectedHubs, setSelectedHubs] = useState<string[]>(
    initialHubs && initialHubs.length >= 2 ? initialHubs : ["INDIANA.HUB", "MICHIGAN.HUB"]
  );
  const [selectedFuels, setSelectedFuels] = useState<string[]>(
    initialFuels && initialFuels.length > 0 ? initialFuels : ["Wind", "Solar", "Natural Gas"]
  );
  const [result, setResult] = useState<ComparisonResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Re-syncs whenever the parent triggers a new compare request (focusToken
  // changes on every click, even if the hubs/fuels/type happen to repeat).
  useEffect(() => {
    if (initialCompareType) setCompareType(initialCompareType);
    if (initialHubs && initialHubs.length >= 2) setSelectedHubs(initialHubs);
    if (initialFuels && initialFuels.length > 0) setSelectedFuels(initialFuels);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusToken]);

  const items = useMemo(() => {
    if (compareType === "hubs") return selectedHubs;
    if (compareType === "fuels") return selectedFuels;
    return [];
  }, [compareType, selectedHubs, selectedFuels]);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError(null);
    compare(compareType, items, controller.signal)
      .then(setResult)
      .catch((err: unknown) => {
        if (controller.signal.aborted) return;
        setError(err instanceof Error ? err.message : "Comparison failed.");
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });
    return () => controller.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [compareType, JSON.stringify(items)]);

  function toggleHub(hubId: string) {
    setSelectedHubs((prev) =>
      prev.includes(hubId) ? prev.filter((h) => h !== hubId) : [...prev, hubId]
    );
  }

  function toggleFuel(fuel: string) {
    setSelectedFuels((prev) =>
      prev.includes(fuel) ? prev.filter((f) => f !== fuel) : [...prev, fuel]
    );
  }

  // Congestion divergence callout: only meaningful with exactly two hubs selected.
  const congestionSpread = useMemo(() => {
    if (compareType !== "hubs" || !result || result.items.length !== 2) return null;
    const [a, b] = result.items.map((h) => h.replace(".HUB", ""));
    let maxSpread = 0;
    let atInterval = "";
    for (const point of result.series) {
      const rtA = point[`${a}_rt`] as number | undefined;
      const rtB = point[`${b}_rt`] as number | undefined;
      if (typeof rtA === "number" && typeof rtB === "number") {
        const diff = Math.abs(rtA - rtB);
        if (diff > maxSpread) {
          maxSpread = diff;
          atInterval = String(point.intervalLabel ?? "");
        }
      }
    }
    return maxSpread > 0 ? { maxSpread, atInterval, a, b } : null;
  }, [result, compareType]);

  return (
    <div className="mt-6 rounded-lg border border-grid-line bg-grid-panel p-4 sm:p-5">
      <h2 className="font-sans text-base font-semibold text-grid-text">Side-by-Side Comparison</h2>

      {/* Tabs */}
      <div className="mt-3 flex gap-1 rounded-md border border-grid-line bg-grid-panel2 p-1 w-fit">
        {COMPARE_TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setCompareType(tab.id)}
            className={`rounded px-3 py-1.5 text-xs font-medium transition-colors ${
              compareType === tab.id ? "bg-teal/15 text-teal" : "text-grid-muted hover:text-grid-text"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Multi-select checkboxes */}
      {compareType === "hubs" && (
        <fieldset className="mt-3">
          <legend className="sr-only">Select hubs to compare</legend>
          <div className="flex flex-wrap gap-3">
            {HUB_OPTIONS.map((hub) => (
              <label key={hub.id} className="inline-flex items-center gap-1.5 text-sm text-grid-text">
                <input
                  type="checkbox"
                  checked={selectedHubs.includes(hub.id)}
                  onChange={() => toggleHub(hub.id)}
                  className="h-4 w-4 rounded border-grid-line bg-grid-panel2 accent-teal"
                />
                {hub.label}
              </label>
            ))}
          </div>
        </fieldset>
      )}

      {compareType === "fuels" && (
        <fieldset className="mt-3">
          <legend className="sr-only">Select fuel types to compare</legend>
          <div className="flex flex-wrap gap-3">
            {FUEL_OPTIONS.map((fuel) => (
              <label key={fuel} className="inline-flex items-center gap-1.5 text-sm text-grid-text">
                <input
                  type="checkbox"
                  checked={selectedFuels.includes(fuel)}
                  onChange={() => toggleFuel(fuel)}
                  className="h-4 w-4 rounded border-grid-line bg-grid-panel2 accent-teal"
                />
                {fuel}
              </label>
            ))}
          </div>
        </fieldset>
      )}

      {loading && (
        <div className="mt-4 flex items-center gap-2 text-sm text-grid-muted" role="status">
          <Loader2 size={16} className="animate-spin" /> Aligning series…
        </div>
      )}

      {error && <p className="mt-4 text-sm text-red-300">Couldn't load comparison. {error}</p>}

      {!loading && !error && result && (
        <div className="mt-4">
          <h3 className="text-sm font-medium text-grid-text">{result.title}</h3>

          {congestionSpread && (
            <div className="mt-2 flex items-center gap-1.5 rounded-md border border-amber/30 bg-amber/10 px-3 py-1.5 text-xs text-amber">
              <Zap size={12} />
              Peak congestion divergence: ${congestionSpread.maxSpread.toFixed(2)}/MWh between{" "}
              {congestionSpread.a} and {congestionSpread.b} at {congestionSpread.atInterval}
            </div>
          )}

          <div className="mt-3">
            <ComparisonChart compareType={compareType} result={result} />
          </div>

          <MetricsTable rows={result.metricsSummary} />

          <p className="mt-2 text-[11px] text-grid-muted">{result.sourceCitation}</p>
        </div>
      )}
    </div>
  );
}

function ComparisonChart({
  compareType,
  result,
}: {
  compareType: CompareType;
  result: ComparisonResponse;
}) {
  if (compareType === "hubs") {
    const prefixes = result.items.map((h) => h.replace(".HUB", ""));
    return (
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={result.series} margin={{ top: 4, right: 8, left: -12, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#28344A" vertical={false} />
          <XAxis dataKey="intervalLabel" stroke="#8B96AC" tick={{ fontSize: 11 }} />
          <YAxis stroke="#8B96AC" tick={{ fontSize: 11 }} unit="$" />
          <Tooltip contentStyle={{ background: "#182338", border: "1px solid #28344A", fontSize: 12 }} />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          {prefixes.map((prefix, i) => (
            <Line
              key={`${prefix}_rt`}
              type="monotone"
              dataKey={`${prefix}_rt`}
              name={`${prefix} Real-Time`}
              stroke={LINE_COLORS[i % LINE_COLORS.length]}
              strokeWidth={2}
              dot={false}
            />
          ))}
          {prefixes.map((prefix, i) => (
            <Line
              key={`${prefix}_da`}
              type="monotone"
              dataKey={`${prefix}_da`}
              name={`${prefix} Day-Ahead`}
              stroke={LINE_COLORS[i % LINE_COLORS.length]}
              strokeDasharray="4 3"
              strokeWidth={1.5}
              dot={false}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    );
  }

  if (compareType === "fuels") {
    return (
      <ResponsiveContainer width="100%" height={280}>
        <BarChart data={result.series} margin={{ top: 4, right: 8, left: -12, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#28344A" vertical={false} />
          <XAxis dataKey="fuel" stroke="#8B96AC" tick={{ fontSize: 11 }} />
          <YAxis stroke="#8B96AC" tick={{ fontSize: 11 }} unit="%" />
          <Tooltip contentStyle={{ background: "#182338", border: "1px solid #28344A", fontSize: 12 }} />
          <Bar dataKey="percentage" name="Grid Share" fill="#3FD6C6" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    );
  }

  // plans
  return (
    <ResponsiveContainer width="100%" height={280}>
      <BarChart data={result.series} margin={{ top: 4, right: 8, left: -12, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#28344A" vertical={false} />
        <XAxis dataKey="category" stroke="#8B96AC" tick={{ fontSize: 11 }} />
        <YAxis stroke="#8B96AC" tick={{ fontSize: 11 }} />
        <Tooltip contentStyle={{ background: "#182338", border: "1px solid #28344A", fontSize: 12 }} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Bar dataKey="projects" name="Projects" fill="#3FD6C6" radius={[4, 4, 0, 0]} />
        <Bar dataKey="miles" name="Line Miles" fill="#E8A33D" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

function MetricsTable({ rows }: { rows: Record<string, unknown>[] }) {
  if (!rows || rows.length === 0) return null;
  const headers = Object.keys(rows[0]);
  return (
    <div className="mt-4 overflow-x-auto rounded-md border border-grid-line">
      <table className="w-full text-left text-xs">
        <thead className="bg-grid-panel2 text-grid-muted">
          <tr>
            {headers.map((h) => (
              <th key={h} className="whitespace-nowrap px-3 py-2 font-medium">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i} className="border-t border-grid-line text-grid-text">
              {headers.map((h) => (
                <td key={h} className="num whitespace-nowrap px-3 py-2">
                  {String(row[h])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
