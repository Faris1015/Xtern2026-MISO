import { useCallback, useRef, useState } from "react";
import OmniSearch from "./components/OmniSearch";
import SessionRadar from "./components/SessionRadar";
import KnowledgeCanvas from "./components/KnowledgeCanvas";
import ComparisonMatrix from "./components/ComparisonMatrix";
import { searchQuery } from "./lib/api";
import type { AudienceMode, CompareType, SearchResponse } from "./types";

const DEFAULT_COMPARE_HUB_QUERY = "compare Indiana and Michigan";

export default function App() {
  const [persona, setPersona] = useState<AudienceMode>("Power Trader");
  const [result, setResult] = useState<SearchResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [compareHubs, setCompareHubs] = useState<string[]>(["INDIANA.HUB", "MICHIGAN.HUB"]);
  const [compareFuels, setCompareFuels] = useState<string[]>([]);
  const [compareType, setCompareType] = useState<CompareType>("hubs");
  // Bumped on every "open the comparison panel" request so ComparisonMatrix
  // re-syncs even when the requested hubs/fuels happen to match what's
  // already selected there.
  const [compareFocusToken, setCompareFocusToken] = useState(0);

  const comparisonRef = useRef<HTMLDivElement>(null);
  const inFlight = useRef<AbortController | null>(null);

  const runSearch = useCallback(
    (query: string, personaOverride?: AudienceMode) => {
      inFlight.current?.abort();
      const controller = new AbortController();
      inFlight.current = controller;

      setLoading(true);
      setError(null);
      searchQuery(query, personaOverride ?? persona, controller.signal)
        .then(setResult)
        .catch((err: unknown) => {
          if (controller.signal.aborted) return;
          setError(err instanceof Error ? err.message : "Search failed.");
        })
        .finally(() => {
          if (!controller.signal.aborted) setLoading(false);
        });
    },
    [persona]
  );

  function handlePersonaChange(next: AudienceMode) {
    setPersona(next);
    if (result) runSearch(result.query, next);
  }

  function openComparisonPanel() {
    setCompareFocusToken((n) => n + 1);
    comparisonRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function handleChipSelect(query: string, type: string) {
    if (type === "compare" || query === DEFAULT_COMPARE_HUB_QUERY) {
      setCompareType("hubs");
      setCompareHubs(["INDIANA.HUB", "MICHIGAN.HUB"]);
      openComparisonPanel();
      return;
    }
    runSearch(query);
  }

  function handleCompareHubs(hubs: string[]) {
    setCompareType("hubs");
    setCompareHubs(hubs);
    openComparisonPanel();
  }

  function handleCompareFuels(fuels: string[]) {
    setCompareType("fuels");
    if (fuels.length > 0) setCompareFuels(fuels);
    openComparisonPanel();
  }

  function handleComparePlans() {
    setCompareType("plans");
    openComparisonPanel();
  }

  return (
    <div className="mx-auto min-h-screen max-w-4xl px-4 py-8 sm:px-6">
      <OmniSearch
        persona={persona}
        onPersonaChange={handlePersonaChange}
        onSearch={(q) => runSearch(q)}
        isLoading={loading}
      />

      <SessionRadar onChipSelect={handleChipSelect} />

      <KnowledgeCanvas
        result={result}
        loading={loading}
        error={error}
        persona={persona}
        onSearch={(q) => runSearch(q)}
        onCompareHubs={handleCompareHubs}
        onCompareFuels={handleCompareFuels}
        onComparePlans={handleComparePlans}
      />

      <div ref={comparisonRef}>
        <ComparisonMatrix
          initialHubs={compareHubs}
          initialFuels={compareFuels}
          initialCompareType={compareType}
          focusToken={compareFocusToken}
        />
      </div>
    </div>
  );
}
