import {
  ApiError,
  type ApiErrorShape,
  type AudienceMode,
  type ComparisonResponse,
  type CompareType,
  type SearchResponse,
  type SessionPrefetchResponse,
} from "../types";

/**
 * Base URL for the FastAPI backend (backend/main.py).
 * Set VITE_API_BASE_URL in frontend/.env for non-local deployments —
 * see .env.example. Defaults to the backend's local dev port (8000).
 */
export const API_BASE_URL: string =
  (import.meta.env.VITE_API_BASE_URL as string | undefined)?.replace(/\/$/, "") ||
  "http://localhost:8000";

async function parseJsonOrThrow<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = (await res.json()) as ApiErrorShape;
      if (body?.detail) detail = body.detail;
    } catch {
      // response wasn't JSON — fall back to statusText
    }
    throw new ApiError(res.status, detail);
  }
  return (await res.json()) as T;
}

/** GET /api/search?q={query}&persona={persona} */
export async function searchQuery(
  q: string,
  persona: AudienceMode = "Power Trader",
  signal?: AbortSignal
): Promise<SearchResponse> {
  const url = `${API_BASE_URL}/api/search?${new URLSearchParams({ q, persona })}`;
  const res = await fetch(url, { signal });
  return parseJsonOrThrow<SearchResponse>(res);
}

/** GET /api/session-prefetch */
export async function getSessionPrefetch(signal?: AbortSignal): Promise<SessionPrefetchResponse> {
  const res = await fetch(`${API_BASE_URL}/api/session-prefetch`, { signal });
  return parseJsonOrThrow<SessionPrefetchResponse>(res);
}

/** GET /api/compare?type={hubs|fuels|plans}&items={csv} */
export async function compare(
  type: CompareType,
  items: string[],
  signal?: AbortSignal
): Promise<ComparisonResponse> {
  const url = `${API_BASE_URL}/api/compare?${new URLSearchParams({
    type,
    items: items.join(","),
  })}`;
  const res = await fetch(url, { signal });
  return parseJsonOrThrow<ComparisonResponse>(res);
}

/**
 * POST /api/generate-briefing — returns the raw PDF bytes as a Blob.
 * Caller is responsible for triggering the browser download (see
 * downloadBlob below) so this stays testable without touching the DOM.
 */
export async function generateBriefing(
  hubId: string,
  audienceMode: AudienceMode = "Power Trader",
  customTitle?: string
): Promise<Blob> {
  const res = await fetch(`${API_BASE_URL}/api/generate-briefing`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      hub_id: hubId,
      audience_mode: audienceMode,
      custom_title: customTitle ?? null,
    }),
  });
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = (await res.json()) as ApiErrorShape;
      if (body?.detail) detail = body.detail;
    } catch {
      // ignore — non-JSON error body
    }
    throw new ApiError(res.status, detail);
  }
  return res.blob();
}

/** Triggers a browser "Save As" for an in-memory Blob. */
export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/**
 * Client-side CSV export for whatever `data` array is currently on
 * screen. The backend has no CSV endpoint, so Issue #4's "Download
 * Filtered CSV" action is fulfilled entirely in the browser from the
 * data already rendered in the canvas.
 */
export function downloadCsv(rows: Record<string, unknown>[], filename: string): void {
  if (!rows || rows.length === 0) return;
  const headers = Array.from(
    rows.reduce((set, row) => {
      Object.keys(row).forEach((k) => set.add(k));
      return set;
    }, new Set<string>())
  );
  const escape = (val: unknown) => {
    const s = val === null || val === undefined ? "" : String(val);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [
    headers.join(","),
    ...rows.map((row) => headers.map((h) => escape(row[h])).join(",")),
  ];
  const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8;" });
  downloadBlob(blob, filename);
}
